import ResoursesSystem as RS
from ResoursesSystem import Material,State
RS.MATERIALS.update({
    "slime":Material("slime")
})
RS.STATES.update({
    "red":State("red",-10),
    "green":State("green",-11),
    "blue":State("blue",-12)
})