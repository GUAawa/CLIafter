import ResoursesSystem as RS
from ResoursesSystem import Storage

class Robot():
    def __init__(self,storage=RS.storages["main"]):
        self.storage:Storage = storage

player:Robot = Robot()