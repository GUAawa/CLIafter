DEFAULT_MANA_PER_STORAGE = 1e8

class Material(): #词根
    def __init__(self,name:str):
        self.name:str = name
    pass
class State(): #词缀
    def __init__(self,name:str,priority:int):
        self.name:str = name
        self.priority:int = priority
    pass

MATERIALS = {"slime":Material("Slime")}
STATES    = [State("",0),State("p1",1),State("p2",2),State("p3",3)]

#物品直接存储材料和物态
class Item():
    def __init__(self,material:Material,states:list[State]):
        self.material:Material = material
        self.states:list[State] = states
    def __str__(self):
        self.states.sort(key=lambda s:s.priority)
        string = ""
        for state in self.states:
            if state.priority<0:
                string+=state.name+'_'
            elif state.priority==0:
                string+=self.material.name
            elif state.priority>0:
                string+='_'+state.name
        return string

#DEBUG
i=Item(MATERIALS["slime"],[STATES[1],STATES[2],STATES[0]])

class Storage():
    def __init__(self,name:str):
        self.name:str = name
        self.items:dict[str,list[Item,int]] = {} #item_name:{Obj_item,amount}
        self.mana:int = DEFAULT_MANA_PER_STORAGE
    def addItem(self,item:Item,amount:int):
        name = str(item)
        if name in self.items:
            self.items[name][1] += amount
        else:
            self.items[name] = [item,amount]

storages:dict[str,Storage] = {
    "main":Storage("main"),
    "t":Storage("t")
}

storages["t"].addItem(i,2)