DEFAULT_MANA_PER_STORAGE = 1e8

class Material(): #词根
    def __init__(self,name:str):
        self.name:str = name
    pass
class State(): #词缀
    def __init__(self,name:str,priority:int):
        self.name:str = name
        self.priority:int = priority
    pass

MATERIALS = {}
STATES    = {"":State("",0)}

#物品直接存储材料和物态
class Item():
    def __init__(self,material:Material,states:list[State]):
        self.material:Material = material
        if STATES[""] not in states:
            states.append(STATES[""])
        self.states:list[State] = states
    def __str__(self):
        self.states.sort(key=lambda s:s.priority)
        string = ""
        for state in self.states:
            if state.priority<0:
                string+=state.name+'_'
            elif state.priority==0:
                string+=self.material.name
            elif state.priority>0:
                string+='_'+state.name
        return string
    def decode(string:str):
        words = string.split('_')
        material:Material = None
        states:list[State] = []
        for word in words:
            if material is None:
                if word in MATERIALS:
                    material = MATERIALS[word]
                    continue
            if word in STATES:
                states.append(STATES[word])
            else:
                raise Exception(f"Bad item: {string}")
        return Item(material,states)
    def __eq__(self, __o: object) -> bool:
        return str(self) == str(__o)
    def __hash__(self) -> int:
        return hash(str(self))

class Storage():
    def __init__(self,name:str):
        self.name:str = name
        self.items:dict[str,list[Item,int]] = {} #item_name:{Obj_item,amount}
        self.mana:int = DEFAULT_MANA_PER_STORAGE
    def addItem(self,item:Item,amount:int):
        name = str(item)
        if name in self.items:
            self.items[name][1] += amount
        else:
            self.items[name] = [item,amount]
        return self.items[name][1]
    def removeItem(self,item:Item,amount:int):
        return self.addItem(item,-amount)
    def checkItem(self,item:Item):
        return self.addItem(item,0)

storages:dict[str,Storage] = {
    "main":Storage("main")
}