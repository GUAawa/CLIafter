import sys,os
from robot import Robot,player

commandsDict:dict[str] = {}

def CLIcmd(obj):
    commandsDict[obj.name] = obj.run

def decode(string:str,robot:Robot = player,do_err = False):
    words = [word for word in string.replace('\n',' ').split(' ') if word!='']
    if len(words) == 0:
        return
    cmd = words[0]
    if cmd not in commandsDict.keys():
        err('unknown command "'+cmd+'"')
        return
    others = words[1::]
    args,options = [],[]
    for word in others:
        if word[0] == '-':
            options.append(word)
        else:
            args.append(word)
    
    if do_err is False:
        try:
            commandsDict[cmd](args,options,robot)
        except Exception as e:
            print(e)
            print("Some thing went wrong... Please report it.")
    else:
        commandsDict[cmd](args,options,robot)

def push(string:str):
    print(string)

def err(string:str):
    print("err:",string)

def init():
    print("Initializing: CLI")

if __name__=="__main__":
    init()
    decode("help main --cn\n")