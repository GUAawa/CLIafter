import CommandLinesInterface as CLI
from CommandLinesInterface import CLIcmd

help_content = {
    "--cn":{
"main":'''
CLIafter, 这里是目录, 输入"help --cn XXX"获得相应信息: 
main : 重读这个目录
how2play : 操作指南
utils : 实用指令
stage0 : 开荒阶段指南
        ''',
"XXX":'''
......查攻略去吧傻子
''',
"how2play":'''
CLIafter是纯CLI游戏, 意味着接下来你都要在这个小黑框里度过了。
通过键入命令来与游戏世界交互, 每个命令都有若干个参数和选项: 
命令 参数1 参数2 参数3 --选项1 -选项2 --选项3 ...
有的选项也会有参数, 只需将其置于选项后(你之后会遇到那种情况的)
''',
"utils":'''
inventory STORAGE_NAME : 查看某仓库的物资(请注意:你当前所在的仓库可以在输入命令处查看, 如main>>>
)
'''
    }
}

@CLIcmd
class Help():
    name = "help"
    def run(args:list[str],options:dict[str,list[str]],storage:str):
        if len(args)!=1:
            return
        if len(options)==0:
            lang="--en"
        elif len(options)==1:
            lang=options[0]
        else:
            return
        if lang not in help_content.keys():
            CLI.err("unknown language")
            return
        if args[0] not in help_content[lang].keys():
            CLI.err("unknown page, try \"help main\"")
        CLI.push(help_content[lang][args[0]])