import CommandLinesInterface as CLI
from CommandLinesInterface import CLIcmd
from robot import Robot
import ResoursesSystem as RS
from ResoursesSystem import Item,MATERIALS,STATES,Storage

IMBUE_RECIPES:dict[Item,tuple]={ #In amount mana Out amount
    Item.decode("red_slime"):(1,1,Item.decode("green_slime"),1),
    Item.decode("green_slime"):(1,1,Item.decode("blue_slime"),1)
}
SLAP_RECIPES:dict[Item,tuple]={ #In amount mana Out amount
    Item.decode("blue_slime"):(1,0,Item.decode("red_slime"),2)
}

RECIPES:dict[str,dict[Item,tuple]]={
    "imbue":IMBUE_RECIPES,
    "slap":SLAP_RECIPES
}

class NormalCraft():
    name = ""
    def run(args:list[str],options:list[str],robot:Robot):
        if len(args) == 0 :
            return CLI.err("missing argument")
        storage:Storage = robot.storage
        input_item:Item = Item.decode(args[0])
        if input_item not in RECIPES[""]:
            return CLI.err("unknown recipe")
        input_amount,mana_cost,output_item,output_amount=RECIPES[""][input_item]

        if storage.checkItem(input_item) >= input_amount and storage.mana >= mana_cost:
            storage.removeItem(input_item,input_amount)
            storage.mana -= mana_cost
            storage.addItem(output_item,output_amount)
        else:
            return CLI.err(f"There is too little {str(input_item)} in the storage:{storage.name}")


@CLIcmd
class Imbue():
    name = "imbue"

    def run(args:list[str],options:list[str],robot:Robot):
        if len(args) == 0 :
            return CLI.err("missing argument")
        storage:Storage = robot.storage
        input_item:Item = Item.decode(args[0])
        if input_item not in RECIPES["imbue"]:
            return CLI.err("unknown recipe")
        input_amount,mana_cost,output_item,output_amount=RECIPES["imbue"][input_item]

        if storage.checkItem(input_item) >= input_amount and storage.mana >= mana_cost:
            storage.removeItem(input_item,input_amount)
            storage.mana -= mana_cost
            storage.addItem(output_item,output_amount)
        else:
            return CLI.err(f"There is too little {str(input_item)} in the storage:{storage.name}")

@CLIcmd
class Slap():
    name = "slap"

    def run(args:list[str],options:list[str],robot:Robot):
        if len(args) == 0 :
            return CLI.err("missing argument")
        storage:Storage = robot.storage
        input_item:Item = Item.decode(args[0])
        if input_item not in RECIPES["slap"]:
            return CLI.err("unknown recipe")
        input_amount,mana_cost,output_item,output_amount=RECIPES["slap"][input_item]

        if storage.checkItem(input_item) >= input_amount and storage.mana >= mana_cost:
            storage.removeItem(input_item,input_amount)
            storage.mana -= mana_cost
            storage.addItem(output_item,output_amount)
        else:
            return CLI.err(f"There is too little {str(input_item)} in the storage:{storage.name}")