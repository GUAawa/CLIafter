import CommandLinesInterface as CLI
from CommandLinesInterface import CLIcmd
import ResoursesSystem as RS

@CLIcmd
class Inventory():
    name = "inventory"
    def run(args,options,storage:str):
        if len(args)==0:
            args = [storage]
        for name in args:
            if name not in RS.storages:
                CLI.err(f"------Unknown: {name}------")
                return
            storage:RS.Storage = RS.storages[name]
            CLI.push(f"------Storage: {name}------")

            mana_rate = storage.mana/RS.DEFAULT_MANA_PER_STORAGE
            if 0 <= mana_rate <= 1:
                CLI.push(f"mana : {storage.mana} [{'#'*int(mana_rate*10)+'-'*(10-int(mana_rate*10))}]")
            elif mana_rate>1:
                CLI.push(f"mana : {storage.mana} [{'#'*10+'$'*int((mana_rate-1)*10)}")
            
            for item_name,(item_obj,item_amount) in storage.items.items():
                CLI.push(
                    f"{item_name} : {item_amount}"
                )