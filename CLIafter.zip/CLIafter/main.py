import CommandLinesInterface as CLI
import ResoursesSystem as RS

import commands

CLI.init()

CLI.decode("help main --cn")
while True:
    CLI.decode(input("main>>>"))