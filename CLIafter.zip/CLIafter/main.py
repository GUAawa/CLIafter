import CommandLinesInterface as CLI
import ResoursesSystem as RS
from robot import Robot,player

import substrances
import commands

CLI.init()

#setup
RS.storages["main"].addItem(RS.Item.decode("red_slime"),1)

CLI.decode("help main --cn")
while True:
    CLI.decode(input(f"{player.storage.name}>>>"))